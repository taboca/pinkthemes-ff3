
char *
strsep (char **stringp, const char *delim);
